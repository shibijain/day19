package com.src.model;

public class Shape {

	private int shapeid;
	private int number;
	
	
	@Override
	public String toString() {
		return "Shape [shapeid=" + shapeid + ", number=" + number + "]";
	}
	
	
	public int getShapeid() {
		return shapeid;
	}
	public void setShapeid(int shapeid) {
		this.shapeid = shapeid;
	}
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
}
