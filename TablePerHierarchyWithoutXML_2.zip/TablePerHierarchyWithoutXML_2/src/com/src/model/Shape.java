package com.src.model;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="sdb")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name="objecttype" ,discriminatorType=DiscriminatorType.STRING)
@DiscriminatorValue(value="sha")
public class Shape {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int shapeid;
	private int number;
	
	
	@Override
	public String toString() {
		return "Shape [shapeid=" + shapeid + ", number=" + number + "]";
	}
	
	
	public int getShapeid() {
		return shapeid;
	}
	public void setShapeid(int shapeid) {
		this.shapeid = shapeid;
	}
	
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	
}
