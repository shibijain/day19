package com.src;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeRegisterServlet
 */
@WebServlet("/EmployeeRegisterServlet")
public class EmployeeRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String empid=request.getParameter("empid");
		String firstname=request.getParameter("fname");
		String middlename=request.getParameter("mname");
		String lastname=request.getParameter("lname");
		String password=request.getParameter("pwd");
		long  mobile=Long.parseLong(request.getParameter("mob"));
		String designation=request.getParameter("des");
		int salary=Integer.parseInt(request.getParameter("sal"));
		String address=request.getParameter("eadd");
		String country=request.getParameter("country");
	
		try {
			DBConnection dbc=new DBConnection();
			String sql="insert into authendication values(?,?)";
			PreparedStatement ps=dbc.getMyprepStatement(sql);
			String sql1="insert into employeedetails values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps1=dbc.getMyprepStatement(sql1);
			
				
				ps.setString(1, empid);
				ps.setString(2, password);
				
				
				ps1.setString(1, empid);
				ps1.setString(2, firstname);
				ps1.setString(3, middlename);
				ps1.setString(4, lastname);
				ps1.setLong(5, mobile);
				ps1.setString(6, designation);
				ps1.setInt(7, salary);
				ps1.setString(8, address);
				ps1.setString(9, country);
				int i=ps.executeUpdate();
				int j=ps1.executeUpdate();
				String message;
				if(i>0 && j>0) {
					message="register sucessfully :) :)";
					response.sendRedirect("index.jsp?msg="+message);
				}
				else
				{
					message="not able to add company";
					response.sendRedirect("Register.jsp?msg="+message);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
