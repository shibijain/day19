package com.src;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CompanyServlet
 */
@WebServlet("/CompanyServlet")
public class CompanyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CompanyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie ck[]=request.getCookies();
		String user=ck[0].getValue();
		int companyid=Integer.parseInt(request.getParameter("cid"));
				String cname=request.getParameter("cname");
		String cadd=request.getParameter("cadd");
		long cmobile=Long.parseLong(request.getParameter("cmob"));
		String depart=request.getParameter("dep");
		DBConnection db=new DBConnection();
		String sql="insert into companydetails values(?,?,?,?,?,?)";
		 try {
			PreparedStatement ps=db.getMyprepStatement(sql);
		    ps.setString(1,user);
		    ps.setInt(2,companyid);
		    ps.setString(3,cname);
		    ps.setString(4,cadd);
		    ps.setLong(5,cmobile);
		    ps.setString(6,depart);
		  
		    int i=ps.executeUpdate();
		    if(i>0) {
		    	response.sendRedirect("Profile.jsp");
		    }else
		    {
		    	response.sendRedirect("Companyreg.jsp");
		    }
		 
		 } catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
