package com.stream1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 List<Student> studentlist = new ArrayList<Student>(); 
	
		 studentlist.add(new Student(11,"John",45));      
	      studentlist.add(new Student(20,"rohini",67));        
	      studentlist.add(new Student(45,"gowrig",335));        
	      studentlist.add(new Student(23,"gowri",23));         
	      studentlist.add(new Student(55,"Maggie",90)) ; 
	      long totalstudent= studentlist.stream().count();
	  	System.out.println("totalStudent="+totalstudent);
	  	 System.out.println();
	  	List<String> failing =studentlist.stream()
                .filter( s -> (s.mark < 50) )
                .map( s -> (s.sid + " " + s.sname+" "+s.mark) )
                .collect( Collectors.toList() ); 
	  	System.out.println("Failing students: ");
        failing.stream().forEach( System.out::println );
        System.out.println();
        List<String> passing = studentlist.stream()
                .filter( s -> (s.mark >50 ) )
                .map( s -> (s.sid + " " + s.sname+" "+s.mark) )
                .collect( Collectors.toList() );
        System.out.println("passing students: ");
        passing.stream().forEach( System.out::println );
        System.out.println();
        System.out.println("Data sorted by score:");
        List<String> l=studentlist.stream()
             .sorted( (s1,s2) -> s1.mark - s2.mark )
             .map( s -> (s.sid + " " + s.sname+" "+s.mark) )
             .collect( Collectors.toList() ) ;
       
        l.stream().forEach( System.out::println );
        System.out.println();
        System.out.println("Data sorted by student id:");
        List<String> li=studentlist.stream()
                .sorted( (s1,s2) -> s1.sid - s2.sid )
                .map( s -> (s.sid + " " + s.sname+" "+s.mark) )
                .collect( Collectors.toList() ) ;
          
           li.stream().forEach( System.out::println );
           System.out.println();
        
	}
}
	 

	
