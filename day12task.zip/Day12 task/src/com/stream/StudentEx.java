package com.stream;

public class StudentEx {

	int sid;
	String sname;
	int mark;
	public StudentEx() {
		
	}
	@Override
	public String toString() {
		return "StudentEx [sid=" + sid + ", sname=" + sname + ", mark=" + mark + "]";
	}
	public StudentEx(int sid, String sname, int mark) {
	
		this.sid = sid;
		this.sname = sname;
		this.mark = mark;
	}
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getMark() {
		return mark;
	}
	public void setMark(int mark) {
		this.mark = mark;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return this.sid=sid;
	}
	
}
