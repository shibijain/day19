package com.stream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;


public class StreamEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 List<StudentEx> studentlist = new ArrayList<StudentEx>(); 
	
		 studentlist.add(new StudentEx(11,"John",45));      
	      studentlist.add(new StudentEx(22,"rohini",67));        
	      studentlist.add(new StudentEx(33,"gowrig",335));        
	      studentlist.add(new StudentEx(44,"gowri",23));         
	      studentlist.add(new StudentEx(55,"Maggie",90));  
	      System.out.println(" student name");
	      List<String> names = studentlist.stream().map(n->n.sname).collect(Collectors.toList());
System.out.println(names);
System.out.println(" greater 40 mark");
List < StudentEx > sortedList = studentlist.stream().filter(s->s.getMark() > 40).sorted(Comparator.comparingInt(StudentEx::getMark))
                                                         .collect(Collectors.toList());
System.out.println(sortedList);
System.out.println(" greater 22 id");
Set<StudentEx> students = studentlist.stream().filter(n-> n.sid>22).collect(Collectors.toSet());
for(StudentEx stu : students) { 
    System.out.println(stu.sid+" "+stu.sname+" "+stu.mark); 
    }
System.out.println(" average mark of student");
    Double avgMark= studentlist.stream()   
            .collect(Collectors.averagingInt(s->s.mark));  
        System.out.println("Average mark of Students is: "+avgMark);
        System.out.println(" start with g ");
        List<StudentEx> firstStudent=studentlist.stream().filter((StudentEx s)-> s.sname.startsWith("g")).collect(Collectors.toList());
        System.out.println(firstStudent);
        System.out.println("minimum mark");
        Comparator<StudentEx> mincomparator = Comparator.comparing( StudentEx::getMark );	
           StudentEx minMarks = studentlist.stream().min(mincomparator).get();
           System.out.println(minMarks);
           System.out.println("max mark");
           Comparator<StudentEx> maxcomparator = Comparator.comparing( StudentEx::getMark);
        	
      StudentEx maxMarks = studentlist.stream().max(maxcomparator).get();
        		           System.out.println(maxMarks);
        		           System.out.println("descending order mark");
 List<StudentEx> sortedList1 = studentlist.stream().sorted(Comparator.comparingInt(StudentEx::getMark).reversed()).collect(Collectors.toList());
	System.out.println(sortedList1);
	 System.out.println("total student ");
	long totalstudent= studentlist.stream().count();
	System.out.println("totalStudent="+totalstudent);
	}

	

	
}
