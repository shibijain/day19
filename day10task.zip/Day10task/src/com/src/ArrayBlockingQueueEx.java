package com.src;

import java.util.concurrent.ArrayBlockingQueue;

public class ArrayBlockingQueueEx {

public static void main(String args[]) {
		ArrayBlockingQueue<StudentQueue> a=new ArrayBlockingQueue(10);
		a.add(new StudentQueue(1,"sk","tp"));
		a.add(new StudentQueue(18,"ak","kp"));
		a.add(new StudentQueue(13,"hk","mp"));
		a.add(new StudentQueue(18,"nk","ap"));
		System.out.println(a);
		
		a.poll();
		System.out.println(a);
		
		a.poll();
		System.out.println(a);
		
		a.poll();
		System.out.println(a);
		
		a.poll();
		System.out.println(a);
		
		a.poll();
		System.out.println(a);
	}

}