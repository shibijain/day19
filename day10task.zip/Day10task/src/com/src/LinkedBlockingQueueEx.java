package com.src;

import java.util.concurrent.LinkedBlockingQueue;

public class LinkedBlockingQueueEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedBlockingQueue l=new LinkedBlockingQueue();
		
		l.add(new StudentQueue(10,"sk","mp"));
		l.add(new StudentQueue(18,"ak","up"));
		l.add(new StudentQueue(5,"dk","pune"));
		l.add(new StudentQueue(53,"rk","mumnai"));
		l.add(new StudentQueue(24,"tk","indore"));
		
		
		System.out.println(l);
		
		System.out.println(l.poll());
		System.out.println(l.peek());
		
		
	}

}