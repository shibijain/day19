package com.io;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class InputOutputStreamEx {

	public static void main(String[] args) throws IOException {
		FileOutputStream fos1=new FileOutputStream("datatypes.txt");
		FileOutputStream fos2=new FileOutputStream("sample.txt");
		FileOutputStream fos3=new FileOutputStream("3.txt");
		String some="this is commom data";
		byte b[]=some.getBytes();
		ByteArrayOutputStream bout=new ByteArrayOutputStream();
		bout.write(b);
		bout.writeTo(fos1);
		bout.writeTo(fos2);
		bout.writeTo(fos3);
		bout.flush();
		bout.close();
		fos1.close();
		fos2.close();
		fos3.close();
		System.out.println("data entered");
		byte[] by= {97,104,98};
		ByteArrayInputStream bin=new ByteArrayInputStream(by);
		int n=0;
		while((n=bin.read())!=-1)
		{//byte , short , int , long , float , double , boolean and char.
			System.out.println("charater datatypes" +(char)n);
			System.out.println("int datatypes "+(int)n);
			System.out.println("double datatypes "+(double)n);
			System.out.println("long datatypes "+(long)n);
			System.out.println("float datatypes "+(float)n);
			
		}
		
		
		
	}		
}