package com.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class PipedStreamEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fos=new FileOutputStream("data.txt");
		PipedOutputStream p=new PipedOutputStream();
		PipedInputStream p1=new PipedInputStream();
		p.connect(p1);
		p.write(23);
		p.write(56);
		p.close();
		
		int n=0;
		while((n=p1.read())!=-1) {
			System.out.println(n);
		}
		
	}

}