package com.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class StudentDetails {

	public static void main(String[] args) throws IOException, ClassNotFoundException ,ClassCastException {
		// TODO Auto-generated method stub
Scanner s=new Scanner(System.in);
FileOutputStream f=new FileOutputStream("object.txt");
ObjectOutputStream oos=new ObjectOutputStream(f);
Student s1=new Student();
s1.setId(s.nextInt());
s1.setStudentname(s.next());
s.nextLine();
s1.setFathername(s.next());
s1.setDob("14Feb1999");
s1.setM(s.nextInt());
s1.setP(s.nextInt());
s1.setP(s.nextInt());
s1.total();
s1.avg();
s1.rank();
System.out.println("object wriiten in to file");
oos.writeObject(s1);
oos.close();
f.close();
FileInputStream fo=new FileInputStream("data.txt");
ObjectInputStream obj=new ObjectInputStream(fo);

int n=0;
while((n=obj.read())!=-1)
{
	System.out.print((char)n);
}
//System.out.println(o.readByte());

	}
	

}