package com.io;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectArrayStreamEx {

	public static void main(String[] args) throws IOException, ClassNotFoundException,EOFException {
		// TODO Auto-generated method stub
		
		FileOutputStream fos1=new FileOutputStream("objects.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos1);
		Student2 s=new Student2("gowri","govindharaj","027/03/1999",60,70,50);
		oos.writeObject(s);
		Student2 s1=new Student2("devi","devifather","02/01/2021",100,300,100);
		oos.writeObject(s1);
		Student2 s3=new Student2("rohini","rohinifather","03/01/2021",90,90,90);
		oos.writeObject(s3);
		oos.close();
		fos1.close();
		System.out.println("object written in to file");
		FileInputStream fis=new FileInputStream("objects.txt");
		ObjectInputStream ois=new ObjectInputStream(fis);
		Student2 stu=null;
		while((stu=(Student2) ois.readObject())!=null)
		{
			System.out.println(stu);
		}
		
		
		

	}

}
