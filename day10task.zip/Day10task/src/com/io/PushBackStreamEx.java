package com.io;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PushbackInputStream;

public class PushBackStreamEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String s="gowri is always greaat";
		byte b[]=s.getBytes();
		ByteArrayInputStream by=new ByteArrayInputStream(b);
		//FileInputStream fis=new FileInputStream(b);
		//PushbackInputStream p=new PushbackInputStream(fis);
		
		PushbackInputStream pbis=new PushbackInputStream(by);
		int i=0;
		while((i=pbis.read())!=-1)
		{
			if(i=='a')
			{
				int j;
				if((j=pbis.read())=='a')
					System.out.print("r");
				else
					{
					pbis.unread(j);
					System.out.print((char)i);
					}
				
				
					
			}
			else
			{
				System.out.print((char)i);
			}
			
		}
		
		
	}
}
