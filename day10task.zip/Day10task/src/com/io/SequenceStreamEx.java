package com.io;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.SequenceInputStream;
import java.util.Enumeration;
import java.util.Vector;

public class SequenceStreamEx {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fis=new FileInputStream("datatypes.txt");
	FileInputStream fis1=new FileInputStream("sample.txt");
		Vector v=new Vector();
		v.add(fis);
	v.add(fis1);
		Enumeration e=v.elements();
		SequenceInputStream sis=new SequenceInputStream(e);
		int i=0;
		while((i=sis.read())!=-1)
		{
			System.out.print((char)i);
		}
		
		

	}

}
