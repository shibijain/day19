package com.io;

import java.io.Serializable;


public class Student2 implements Serializable{

	
	public Student2(String sname, String father_name, String dob, int m, int p, int c) {
		//super();
		this.sname = sname;
		this.father_name = father_name;
		this.dob = dob;
		this.m = m;
		this.p = p;
		this.c = c;
	}


	private String sname;
	private String father_name;
	private String dob;
	private int total;
	private double average;
	private int m,p,c;
	private int rank;
	
	
	@Override
	public String toString() {
		return "Student2 [sname=" + sname + ", father_name=" + father_name + ", dob=" + dob + ", total=" + total()
				+ ", average=" + average() + ", m=" + m + ", p=" + p + ", c=" + c + ", rank=" +  rank()  + "]";
	}


	public Student2() {}


	public String getSname() {
		return sname;
	}


	public void setSname(String sname) {
		this.sname = sname;
	}


	public String getFather_name() {
		return father_name;
	}


	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public int getM() {
		return m;
	}


	public void setM(int m) {
		this.m = m;
	}


	public int getP() {
		return p;
	}


	public void setP(int p) {
		this.p = p;
	}


	public int getC() {
		return c;
	}


	public void setC(int c) {
		this.c = c;
	}
	 int total()
	 {
	 	int r=m+p+c;
	 	return r;
	 }
	 public double average()
	 {
	 	return total()/3;
	 }
	 
	 public String rank() {
			if(average()>=75 && average()<100) {return "A";}
			else if(average()>=50 && average()<75) {return "B";}
			else {return "C";}}	 
	
	 
	 

	
	

}
