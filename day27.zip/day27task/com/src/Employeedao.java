package com.src;

public class Employeedao {    
  private JdbcTemplate  jt;    
    
public void setJt(JdbcTemplate jt) {    
    this.jt = jt;    
}    
public int save(Employee p){    
    String sql="insert into Employee(name,salary,designation) values('"+p.getName()+"',"+p.getSalary()+",'"+p.getDesignation()+"')";    
    return jt.update(sql);    
}    
public int update(Employee p){    
    String sql="update Employee set name='"+p.getName()+"', salary="+p.getSalary()+",designation='"+p.getDesignation()+"' where id="+p.getId()+"";    
    return jt.update(sql);    
}    
public int delete(int id){    
    String sql="delete from Employee where id="+id+"";    
    return jt.update(sql);    
}    
public Employee getEmpById(int id){    
    String sql="select * from Employee where id=?";    
    return jt.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Employee>(Employee.class));    
}    
public List<Employee> getEmployees(){    
    return jt.query("select * from Employee",new RowMapper<Employee>(){    
        public Employee mapRow(ResultSet rs, int row) throws SQLException {    
            Employee e=new Employee();    
            e.setId(rs.getInt(1));    
            e.setName(rs.getString(2));    
            e.setSalary(rs.getFloat(3));    
            e.setDesignation(rs.getString(4));    
            return e;    
        }    
    });    
}    
}  