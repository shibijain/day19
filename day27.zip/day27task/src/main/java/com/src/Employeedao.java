package com.src;
import java.sql.ResultSet;    
import java.sql.SQLException;    
import java.util.List;    
import org.springframework.jdbc.core.BeanPropertyRowMapper;    
import org.springframework.jdbc.core.JdbcTemplate;    
import org.springframework.jdbc.core.RowMapper;     

public class Employeedao {    
  private JdbcTemplate  jtemp;    
    

public JdbcTemplate getJtemp() {
	return jtemp;
}
public void setJtemp(JdbcTemplate jtemp) {
	this.jtemp = jtemp;
}
public int save(Employee p){    
    String sql="insert into Employee(name,salary,designation) values('"+p.getName()+"',"+p.getSalary()+",'"+p.getDesignation()+"')";    
    return jtemp.update(sql);    
}    
public int update(Employee p){    
    String sql="update Employee set name='"+p.getName()+"', salary="+p.getSalary()+",designation='"+p.getDesignation()+"' where id="+p.getId()+"";    
    return jtemp.update(sql);    
}    
public int delete(int id){    
    String sql="delete from Employee where id="+id+"";    
    return jtemp.update(sql);    
}    
public Employee getEmpById(int id){    
    String sql="select * from Employee where id=?";    
    return jtemp.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Employee>(Employee.class));    
}    
public List<Employee> getEmployees(){    
    return jtemp.query("select * from Employee",new RowMapper<Employee>(){    
        public Employee mapRow(ResultSet rs, int row) throws SQLException {    
            Employee e=new Employee();    
            e.setId(rs.getInt(1));    
            e.setName(rs.getString(2));    
            e.setSalary(rs.getFloat(3));    
            e.setDesignation(rs.getString(4));    
            return e;    
        }    
    });    
}    
}  